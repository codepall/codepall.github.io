apt update
apt upgrade -y
apt install x11-repo -y
apt install termux-x11-nightly -y
apt install dbus -y
mkdir .shortcuts
cp storage/downloads/dexmode/start.sh .shortcuts
cp storage/downloads/dexmode/start.sh .
apt install proot-distro -y
proot-distro install debian
proot-distro login debian -- apt update
proot-distro login debian -- apt upgrade -y
proot-distro login debian -- apt install xfce4 -y
proot-distro login debian -- apt install firefox-esr -y
proot-distro login debian -- apt install libreoffice -y
proot-distro login debian -- adduser admin
bash start.sh
