am start com.termux.x11/com.termux.x11.MainActivity
pd login debian --user admin --termux-home --shared-tmp -- termux-x11 :0 -xstartup "dbus-launch --exit-with-session xfce4-session"